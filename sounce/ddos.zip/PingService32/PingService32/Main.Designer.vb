﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Titkle = New System.Windows.Forms.Label()
        Me.UIT = New System.Windows.Forms.Label()
        Me.IP_DATA = New System.Windows.Forms.TextBox()
        Me.START_ = New System.Windows.Forms.Button()
        Me.End_ = New System.Windows.Forms.Button()
        Me.STOP_ = New System.Windows.Forms.Button()
        Me.MOPous = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Titkle
        '
        Me.Titkle.AutoSize = True
        Me.Titkle.BackColor = System.Drawing.Color.Transparent
        Me.Titkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Titkle.Font = New System.Drawing.Font("微软雅黑", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Titkle.Location = New System.Drawing.Point(12, 21)
        Me.Titkle.Name = "Titkle"
        Me.Titkle.Size = New System.Drawing.Size(97, 31)
        Me.Titkle.TabIndex = 0
        Me.Titkle.Text = "目标IP :"
        '
        'UIT
        '
        Me.UIT.AutoSize = True
        Me.UIT.BackColor = System.Drawing.Color.Transparent
        Me.UIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UIT.Font = New System.Drawing.Font("微软雅黑", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.UIT.Location = New System.Drawing.Point(12, 69)
        Me.UIT.Name = "UIT"
        Me.UIT.Size = New System.Drawing.Size(323, 20)
        Me.UIT.TabIndex = 1
        Me.UIT.Text = "启动后会后台运行PING，下面填写启动的进程数量"
        '
        'IP_DATA
        '
        Me.IP_DATA.BackColor = System.Drawing.Color.White
        Me.IP_DATA.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.IP_DATA.Location = New System.Drawing.Point(115, 30)
        Me.IP_DATA.MaxLength = 15
        Me.IP_DATA.Name = "IP_DATA"
        Me.IP_DATA.Size = New System.Drawing.Size(257, 22)
        Me.IP_DATA.TabIndex = 2
        '
        'START_
        '
        Me.START_.AutoSize = True
        Me.START_.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.START_.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.START_.FlatAppearance.BorderSize = 0
        Me.START_.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.START_.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.START_.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.START_.Location = New System.Drawing.Point(288, 142)
        Me.START_.Name = "START_"
        Me.START_.Size = New System.Drawing.Size(84, 31)
        Me.START_.TabIndex = 3
        Me.START_.Text = "开始攻击"
        Me.START_.UseVisualStyleBackColor = True
        '
        'End_
        '
        Me.End_.AutoSize = True
        Me.End_.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.End_.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.End_.FlatAppearance.BorderSize = 0
        Me.End_.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.End_.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.End_.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.End_.Location = New System.Drawing.Point(18, 142)
        Me.End_.Name = "End_"
        Me.End_.Size = New System.Drawing.Size(52, 31)
        Me.End_.TabIndex = 4
        Me.End_.Text = "退出"
        Me.End_.UseVisualStyleBackColor = True
        '
        'STOP_
        '
        Me.STOP_.AutoSize = True
        Me.STOP_.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.STOP_.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen
        Me.STOP_.FlatAppearance.BorderSize = 0
        Me.STOP_.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.STOP_.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.STOP_.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.STOP_.Location = New System.Drawing.Point(150, 142)
        Me.STOP_.Name = "STOP_"
        Me.STOP_.Size = New System.Drawing.Size(84, 31)
        Me.STOP_.TabIndex = 5
        Me.STOP_.Text = "停止攻击"
        Me.STOP_.UseVisualStyleBackColor = True
        '
        'MOPous
        '
        Me.MOPous.BackColor = System.Drawing.Color.White
        Me.MOPous.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MOPous.Location = New System.Drawing.Point(21, 103)
        Me.MOPous.MaxLength = 999999999
        Me.MOPous.Name = "MOPous"
        Me.MOPous.Size = New System.Drawing.Size(351, 22)
        Me.MOPous.TabIndex = 6
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.ForestGreen
        Me.ClientSize = New System.Drawing.Size(384, 191)
        Me.ControlBox = False
        Me.Controls.Add(Me.MOPous)
        Me.Controls.Add(Me.STOP_)
        Me.Controls.Add(Me.End_)
        Me.Controls.Add(Me.START_)
        Me.Controls.Add(Me.IP_DATA)
        Me.Controls.Add(Me.UIT)
        Me.Controls.Add(Me.Titkle)
        Me.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(400, 230)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(400, 230)
        Me.Name = "Main"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "死亡之PING"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Titkle As Label
    Friend WithEvents UIT As Label
    Friend WithEvents IP_DATA As TextBox
    Friend WithEvents START_ As Button
    Friend WithEvents End_ As Button
    Friend WithEvents STOP_ As Button
    Friend WithEvents MOPous As TextBox
End Class
