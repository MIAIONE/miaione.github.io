﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' 有关程序集的一般信息由以下
' 控制。更改这些特性值可修改
' 与程序集关联的信息。

'查看程序集特性的值

<Assembly: AssemblyTitle("死亡之Ping")>
<Assembly: AssemblyDescription("Ping死你想Ping的电脑")>
<Assembly: AssemblyCompany("MIAIONE Studio")>
<Assembly: AssemblyProduct("PingService32")>
<Assembly: AssemblyCopyright("MIAIONE")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
<Assembly: Guid("58dac126-90b9-4bca-9670-0e0b949e4b30")>

' 程序集的版本信息由下列四个值组成: 
'
'      主版本
'      次版本
'      生成号
'      修订号
'
' 可以指定所有值，也可以使用以下所示的 "*" 预置版本号和修订号
' 方法是按如下所示使用“*”: :
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("233.0.0.0")>
<Assembly: AssemblyFileVersion("233.0.0.0")>
